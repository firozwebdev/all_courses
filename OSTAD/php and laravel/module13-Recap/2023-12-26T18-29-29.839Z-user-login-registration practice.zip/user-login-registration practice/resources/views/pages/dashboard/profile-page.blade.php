@extends('layout.app')
@section('content')
    @include('components.dashboard.profile-form')
@endsection

