<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-7 col-lg-6 center-screen">
            <div class="card w-100 p-4">
                <div class="card-body">
                    <h6>SET NEW PASSWORD</h6>
                    <br/>
                    <label>New Password</label>
                    <input id="password" placeholder="New Password" class="form-control form-control-sm" type="password"/>
                    <br/>
                    <label>Confirm Password</label>
                    <input id="cpassword" placeholder="Confirm Password" class="form-control form-control-sm" type="password"/>
                    <br/>
                    <button onclick="ResetPass()" class="btn w-100 btn-sm btn-success">Next</button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
  async function ResetPass() {
        let password = document.getElementById('password').value;
        let cpassword = document.getElementById('cpassword').value;

        if(password.length===0){
            alert('Password is required')
        }
        else if(cpassword.length===0){
            alert('Confirm Password is required')
        }
        else if(password!==cpassword){
            alert('Password and Confirm Password must be same')
        }
        else{
          showLoader()
          let res=await axios.post("/reset-password",{password:password});
          hideLoader();
          if(res.status===200 && res.data['status']==='success'){
              alert(res.data['message']);
              window.location.href="/userLogin";

          }
          else{
            alert(res.data['message'])
          }
        }

    }
</script>
<?php /**PATH /Users/rabbilhasan/Desktop/pre-recorded/resources/views/components/auth/reset-pass-form.blade.php ENDPATH**/ ?>