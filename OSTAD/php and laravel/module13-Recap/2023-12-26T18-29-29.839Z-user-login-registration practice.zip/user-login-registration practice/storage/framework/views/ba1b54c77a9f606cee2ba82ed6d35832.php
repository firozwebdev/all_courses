<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-7 col-lg-6 center-screen">
            <div class="card  w-100  p-4">
                <div class="card-body">
                    <h6>ENTER OTP CODE</h6>
                    <br/>
                    <label>4 Digit Code Here</label>
                    <input id="otp" placeholder="Code" class="form-control form-control-sm" type="text"/>
                    <br/>
                    <button onclick="VerifyOtp()"  class="btn w-100 btn-success">Next</button>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
   async function VerifyOtp() {
        let otp = document.getElementById('otp').value;
        if(otp.length !==4){
           alert('Invalid OTP')
        }
        else{
            showLoader();
            let res=await axios.post('/verify-otp', {
                otp: otp,
                email:sessionStorage.getItem('email')
            })
            hideLoader();

            if(res.status===200 && res.data['status']==='success'){
                alert(res.data['message'])
                sessionStorage.clear();
                window.location.href='/resetPassword'
            }
            else{
                alert(res.data['message'])
            }
        }
    }
</script>
<?php /**PATH /Users/rabbilhasan/Desktop/pre-recorded/resources/views/components/auth/verify-otp-form.blade.php ENDPATH**/ ?>