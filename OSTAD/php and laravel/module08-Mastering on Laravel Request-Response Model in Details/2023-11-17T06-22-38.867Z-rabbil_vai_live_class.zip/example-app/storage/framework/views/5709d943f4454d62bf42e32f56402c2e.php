<h1>I am blade view</h1>
<?php /**PATH /Users/rabbilhasan/Desktop/laravel_practice/example-app/resources/views/pages/hello.blade.php ENDPATH**/ ?>