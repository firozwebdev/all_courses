<?php

use App\Http\Controllers\DemoController;
use Illuminate\Support\Facades\Route;


//1. String Int Null Boolean Response
Route::get('/Demo1', [DemoController::class,'Demo1']);


//2. Array & Associative Array Response
Route::get('/Demo2', [DemoController::class,'Demo2']);


//3. Json Response
Route::get('/Demo3', [DemoController::class,'Demo3']);



//4. Response with data, msg, code
Route::get('/Demo4', [DemoController::class,'Demo4']);



//5. Response redirect
Route::get('/Demo5', [DemoController::class,'Demo5']);



//6. Binary File Response
Route::get('/Demo6', [DemoController::class,'Demo6']);



// 7. File Download Response
Route::get('/Demo7', [DemoController::class,'Demo7']);


// 8. Response Cookies
Route::get('/Demo8', [DemoController::class,'Demo8']);


// 9. Response with header properties
Route::get('/Demo9', [DemoController::class,'Demo9']);


// 10. Response blade view
Route::get('/Demo10',[DemoController::class,'Demo10']);
