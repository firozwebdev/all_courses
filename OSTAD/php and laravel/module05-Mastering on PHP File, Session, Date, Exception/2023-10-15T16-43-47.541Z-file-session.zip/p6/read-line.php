<?php 
//read the file in array
$lines = file("./data.txt");
echo "<pre>";
print_r($lines);
echo "</pre>";