<?php 
echo "This is coming from the webserver";