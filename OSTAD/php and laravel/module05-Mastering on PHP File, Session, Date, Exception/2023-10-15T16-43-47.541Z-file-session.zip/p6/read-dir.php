<?php 
// echo file_exists("./data.txt");
echo is_dir("./storage");