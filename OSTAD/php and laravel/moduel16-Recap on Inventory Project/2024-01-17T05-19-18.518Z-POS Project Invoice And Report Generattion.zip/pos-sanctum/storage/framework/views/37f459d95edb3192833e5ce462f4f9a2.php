<?php $__env->startSection('content'); ?>

 <div class="p-5">
     <ul>
         <li>Phase 01-------> Start</li>
         <li>Phase 02</li>
         <li>Phase 03</li>
         <li>Phase 04</li>
         <li>Phase 05</li>

     </ul>
     <a href="<?php echo e(url("/userLogin")); ?>" class="btn float-start bg-gradient-primary">Start Here</a>
 </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rabbilhasan/Desktop/pos-sanctum/resources/views/pages/home.blade.php ENDPATH**/ ?>