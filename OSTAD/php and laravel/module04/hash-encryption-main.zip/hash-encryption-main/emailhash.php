<?php 
$originalText = "Bondhu tumi agamikal Uttara Starbase restaurant e asho";
$hash = md5($originalText);

$originalHash = '1bb573c842302e71be5eb8082bbf9b2e';

echo $hash;
