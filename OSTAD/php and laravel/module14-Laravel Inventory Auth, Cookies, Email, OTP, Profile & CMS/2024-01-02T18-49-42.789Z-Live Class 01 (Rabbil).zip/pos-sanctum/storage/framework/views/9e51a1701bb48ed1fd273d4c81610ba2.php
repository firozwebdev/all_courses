<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('components.auth.reset-pass-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rabbilhasan/Documents/GitHub/Laravel-Batch/Laravel-Batch/Point Of Sale/pos-sanctum/resources/views/pages/auth/reset-pass-page.blade.php ENDPATH**/ ?>