from django.shortcuts import render
from django.http import HttpResponse


# Create your views here.
def course(request):
    return HttpResponse('Welcome to Django for web & AI')

def data_science(request):
    available_course={'fcourse':['Machine Learning', 'Deep learning', 'Big Data', 'Django', 'AWS']}
    return render(request, 'courses/datascience.html', available_course)

def big_data(request):
    return render(request,'courses/bigdata.html')

def data_analysis(request):
    return render(request,'courses/dataanalysis.html')

def deep_learning(request):
    return HttpResponse('Welcome to deep_learning Course')



