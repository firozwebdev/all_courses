from django.shortcuts import render
from django.http import HttpResponse


# Create your views here.
def course(request):
    return HttpResponse('Welcome to Django for web & AI')

def data_science(request):
    return HttpResponse('Welcome to Data Science Course')

def big_data(request):
    return HttpResponse('Welcome to big data Course')

def data_analysis(request):
    return HttpResponse('Welcome to Data analysis Course')

def deep_learning(request):
    return HttpResponse('Welcome to deep_learning Course')



